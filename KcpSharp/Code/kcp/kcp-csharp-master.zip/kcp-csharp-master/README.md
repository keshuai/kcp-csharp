# kcp-csharp
KCP - A Fast and Reliable ARQ Protocol

## TODO
- [ ] FEC(Forward Error Correction) Based on  Reed-Solomon Codes
- [ ] Packet level encryption

## Links
1. skywind3000 [KCP](https://github.com/skywind3000/kcp)  
2. xtaci [kcp-go](https://github.com/xtaci/kcp-go)   
